import React, { useState, useEffect, useRef } from "react";
import { Link, useNavigate } from "react-router-dom";
import { cn, getLatestGmpValue } from "@/lib/utils";

import { ChevronRight } from "lucide-react"





const statusColor: Record<string, string> = {
    Active:
        "bg-emerald-100 text-emerald-800 border-emerald-300 group-hover:bg-emerald-500 group-hover:text-white group-hover:border-emerald-500 transition-all duration-300",
    Upcoming:
        "bg-blue-100 text-blue-800 border-blue-300 group-hover:bg-blue-600 group-hover:text-white group-hover:border-blue-600 transition-all duration-300",
    "Issue Closed (Unlisted)":
        "bg-yellow-100 text-yellow-800 border-yellow-300 group-hover:bg-yellow-500 group-hover:text-white group-hover:border-yellow-500 transition-all duration-300",
    Listed:
        "bg-slate-50 text-slate-700 border-slate-300 group-hover:bg-slate-100 group-hover:text-slate-900 group-hover:border-slate-400 transition-all duration-300",

    Inactive:
        "bg-rose-100 text-rose-800 border-rose-300 group-hover:bg-rose-600 group-hover:text-white group-hover:border-rose-600 transition-all duration-300",
    "Listing Today":
        "bg-red-100 text-red-800 border-red-300 group-hover:bg-red-600 group-hover:text-white group-hover:border-red-600 transition-all duration-300",
    "Date Not Declared":
        "bg-orange-100 text-orange-800 border-orange-300 group-hover:bg-orange-600 group-hover:text-white group-hover:border-orange-600 transition-all duration-300",
};


const getCalculatedStatus = (item: any) => {
    if (item.status === "Inactive") return "Inactive";

    if (
        item.date_declared === "No" ||
        item.date_declared === "Date Not Declared" ||
        !item.date_declared ||
        item.date_declared === "" ||
        item.date_declared === "0" ||
        item.date_declared === 0
    ) {
        return "Date Not Declared";
    }

    const now = new Date();
    now.setHours(0, 0, 0, 0);

    const openDate = item.open_date ? new Date(item.open_date) : null;
    const closeDate = item.close_date ? new Date(item.close_date) : null;
    const listingDate = item.listing_date ? new Date(item.listing_date) : null;

    // normalize dates
    openDate?.setHours(0, 0, 0, 0);
    closeDate?.setHours(0, 0, 0, 0);
    listingDate?.setHours(0, 0, 0, 0);

    if (openDate && now < openDate) {
        return "Upcoming";
    }

    if (openDate && closeDate && now >= openDate && now <= closeDate) {
        return "Active";
    }

    if (closeDate && listingDate && now > closeDate && now < listingDate) {
        return "Issue Closed (Unlisted)";
    }

    // 👇 Listing Today
    if (listingDate && now.getTime() === listingDate.getTime()) {
        return "Listing Today";
    }

    // 👇 Already Listed
    if (listingDate && now > listingDate) {
        return "Listed";
    }

    return item.status || "Upcoming";
};

const actionBtn: Record<string, { label: string; cls: string }> = {
    Active: {
        label: "View Details",
        cls: "bg-blue-900 text-white hover:bg-blue-800",
    },
    Upcoming: {
        label: "View Details",
        cls: "bg-slate-200 text-slate-700 hover:bg-slate-300",
    },
    "Issue Closed (Unlisted)": {
        label: "View Details",
        cls: "border border-blue-900 text-blue-900 hover:bg-blue-50",
    },
    Listed: {
        label: "View Details",
        cls: "bg-blue-900 text-white hover:bg-blue-800",
    },
    Inactive: {
        label: "Inactive",
        cls: "bg-rose-50 text-rose-300 cursor-not-allowed",
    },
    "Date Not Declared": {
        label: "View Details",
        cls: "bg-orange-600 text-white hover:bg-orange-700",
    },
};


const LiveIPOs = () => {
    const navigate = useNavigate();
    const [ipos, setIpos] = useState<any[]>([]);
    const scrollRef = useRef<HTMLDivElement>(null);

    useEffect(() => {
        const fetchLiveIPOs = async () => {
            try {
                const res = await fetch("/api/ipo-lists?limit=3");
                const data = await res.json();
                if (data && data.data) {
                    const mapped = data.data.map((item: any) => {
                        const calculatedStatus = getCalculatedStatus(item);

                        return {
                            id: item.id,
                            companyName: item.issuer_company,
                            status: calculatedStatus,
                            priceRange: (() => {
                                const low = item.issue_lowest_price;
                                const high = item.issue_highest_price;
                                if ((!low || low === '0' || low === 0) && (!high || high === '0' || high === 0)) return "TBA";
                                if (!low || low === '0' || low === 0) return `₹${high}`;
                                if (!high || high === '0' || high === 0 || low === high) return `₹${low}`;
                                return `₹${low} - ₹${high}`;
                            })(),
                            gmp: getLatestGmpValue(item.gmp),
                            subscription: item.subscription || "Check Details",
                            lotSize: item.lot_size || "—",
                            issue_highest_price: item.issue_highest_price || 100,
                            slug: item.blog_slug,
                        };
                    });
                    setIpos(mapped);
                }
            } catch (err) {
                console.error("Error fetching live IPOs:", err);
            }
        };
        fetchLiveIPOs();
    }, []);

    const isMobile = useRef(
        typeof window !== "undefined" &&
        window.innerWidth < 768
    ).current;


    useEffect(() => {
        const interval = setInterval(() => {
            if (scrollRef.current && isMobile && ipos.length > 0) {
                const { scrollLeft, scrollWidth, clientWidth } = scrollRef.current;
                const maxScroll = scrollWidth - clientWidth;
                let nextScroll = scrollLeft + clientWidth;
                if (scrollLeft >= maxScroll - 10) nextScroll = 0;
                scrollRef.current.scrollTo({ left: nextScroll, behavior: "smooth" });
            }
        }, 5000);
        return () => clearInterval(interval);
    }, [ipos, isMobile]);

    return (
        <section className="py-20 px-4 container mx-auto">
            <div


                className="flex justify-between items-end mb-12"
            >
                <div>
                    <span className="text-[#f99810] font-bold tracking-widest uppercase text-xs mb-2 block">
                        Market Watch
                    </span>
                    <h2 className="text-4xl font-extrabold tracking-tight text-slate-900">
                        Live <strong style={{ color: "#f99810" }}>IPO</strong> Listings
                    </h2>
                    <p className="text-gray-600 pt-4">
                        Track ongoing, upcoming and closed IPOs with key details including
                        price band, GMP and subscription status
                    </p>
                </div>
                <Link
                    to="/all-ipos"
                    className="hidden md:flex text-blue-900 font-bold items-center gap-1 hover:underline"
                >
                    View all listings <ChevronRight className="h-4 w-4" />
                </Link>
            </div>
            <div
                ref={scrollRef}
                className="overflow-x-auto pb-4 scrollbar-hide snap-x snap-mandatory"
            >
                <div className="flex gap-6 md:grid md:grid-cols-3 md:gap-8">
                    {ipos.map((ipo, idx) => {
                        const btn = actionBtn[ipo.status] || actionBtn.Upcoming;

                        return (
                            <div
                                key={ipo.id}

                                onClick={() =>
                                    navigate(ipo.slug ? `/ipo-blogs/${ipo.slug}` : "/all-ipos")
                                }
                                className="flex-shrink-0 w-[85vw] md:w-auto snap-center bg-white p-6 rounded-2xl shadow-[0_12px_40px_rgba(25,28,30,0.06)] transition-all group border border-slate-100 flex flex-col cursor-pointer"
                            >
                                <div className="flex justify-between items-start mb-6">
                                    <div className="w-16 h-16 rounded-xl bg-slate-100 flex items-center justify-center font-bold text-blue-900 text-lg group-hover:bg-blue-900 group-hover:text-white transition-colors duration-200 text-center p-2">
                                        {ipo.companyName.slice(0, 2).toUpperCase()}
                                    </div>
                                    <span
                                        className={cn(
                                            "px-3 py-1 text-[10px] font-black uppercase tracking-tighter rounded-full border transition-all",
                                            statusColor[ipo.status] ||
                                            "bg-slate-50 text-slate-500 border-slate-200",
                                        )}
                                    >
                                        {ipo.status === "Active" ? "Open" : ipo.status}
                                    </span>
                                </div>
                                <h3 className="text-xl font-bold mb-4 group-hover:text-blue-900 transition-colors text-slate-900 line-clamp-1">
                                    {ipo.companyName}
                                </h3>
                                <div className="grid grid-cols-2 gap-y-4 mb-6 flex-1">
                                    <div>
                                        <p className="text-xs text-slate-500">Price Band</p>
                                        <p className="text-sm font-bold text-slate-900">
                                            {ipo.priceRange}
                                        </p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-slate-500">GMP</p>
                                        <p className="text-sm font-bold text-green-700">
                                            {ipo.gmp !== "—" ? ipo.gmp : ""}
                                        </p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-slate-500">Subscription</p>
                                        <p className="text-sm font-bold text-slate-900">
                                            {ipo.subscription}
                                        </p>
                                    </div>
                                    <div>
                                        <p className="text-xs text-slate-500">Lot Size</p>
                                        <p className="text-sm font-bold text-slate-900">
                                            {ipo.lotSize} shares
                                        </p>
                                    </div>
                                </div>
                                <Link
                                    to={ipo.slug ? `/ipo-blogs/${ipo.slug}` : "/all-ipos"}
                                    className={`w-full py-3 rounded-xl font-bold transition-all active:scale-95 mt-auto flex items-center justify-center ${btn.cls}`}
                                >
                                    {btn.label}
                                </Link>
                            </div>
                        );
                    })}
                </div>
            </div>
        </section>
    );
};

export default React.memo(LiveIPOs);