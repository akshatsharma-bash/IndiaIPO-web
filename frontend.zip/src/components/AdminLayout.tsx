import { useState, useEffect, useRef } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "@/contexts/AuthContext";
import { LayoutDashboard, FileText, BookOpen, Users, MessageSquare, Settings, LogOut, Menu, X, TrendingUp, Globe, Navigation, Layout, Image, Building2, GraduationCap, Bell, Video, Newspaper, Briefcase, PlayCircle, ClipboardCheck, Megaphone, HelpCircle, LayoutGrid, Mail } from "lucide-react";
import { Button } from "@/components/ui/button";
import logo from "@/assets/logo.png";

const sidebarLinks = [
  { label: "Dashboard", href: "/admin", icon: LayoutDashboard },
  { label: "Manage IPO Calendar", href: "/admin/ipos", icon: TrendingUp },
  { label: "Manage Sectors", href: "/admin/sectors", icon: LayoutGrid },
  { label: "List IPO By Sector", href: "/admin/sector-ipos", icon: LayoutGrid },

  { label: "Manage Magazines", href: "/admin/magazines", icon: BookOpen },
  { label: "News / Updates", href: "/admin/news", icon: Newspaper },
  { label: "Manage Banker Categories", href: "/admin/banker-categories", icon: Building2 },
  { label: "Merchant Bankers (SME)", href: "/admin/merchant-bankers", icon: Building2 },
  { label: "Mainboard Bankers", href: "/admin/mainboard-bankers", icon: Building2 },

  { label: "IPO Knowledge", href: "/admin/knowledge", icon: GraduationCap },
  { label: "Manage Registrars", href: "/admin/registrars", icon: Users },
  { label: "Registrar FAQs", href: "/admin/registrar-faqs", icon: HelpCircle },
  { label: "Notifications PDFs", href: "/admin/notifications", icon: Bell },

  { label: "Market Snaps", href: "/admin/market-snaps", icon: PlayCircle },
  { label: "Daily Reporter", href: "/admin/daily-digests", icon: FileText },
  { label: "Daily Digest Campaign", href: "/admin/daily-digest-campaign", icon: Megaphone },
  { label: "Leads", href: "/admin/leads", icon: MessageSquare, badgeKey: "leads" },
  { label: "Consultant Enquiries", href: "/admin/consultant-enquiries", icon: MessageSquare, badgeKey: "consultantEnquiries" },
  { label: "Merchant Enquiries", href: "/admin/merchant-enquiries", icon: MessageSquare, badgeKey: "merchantEnquiries" },
  { label: "Investor Enquiries", href: "/admin/investors", icon: Briefcase },
  { label: "Check IPO Feasibility", href: "/admin/ipo-feasibility", icon: ClipboardCheck },
  { label: "Career Applications", href: "/admin/career-applications", icon: GraduationCap },
  { label: "Subscriptions", href: "/admin/subscriptions", icon: Mail },
  { label: "Annual Report Requests", href: "/admin/annual-report-requests", icon: FileText },
  { label: "Manage CSR", href: "/admin/csr", icon: Globe },
  { label: "Manage Consultants", href: "/admin/consultants", icon: Users },

  { label: "Pages", href: "/admin/pages", icon: Layout },

  { label: "Manage Blogs", href: "/admin/ipo-blogs", icon: BookOpen },
  { label: "Site Popup", href: "/admin/popup", icon: Megaphone },
  { label: "Manage Banners", href: "/admin/banners", icon: Image },
  { label: "Manage Users", href: "/admin/users", icon: Users },
  { label: "SEO Settings", href: "/admin/seo", icon: Settings },
  { label: "Admin Profile", href: "/admin/profile", icon: Settings },
];

const AdminLayout = ({ children }: { children: React.ReactNode }) => {
  const { user, logout, isAdmin } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [unreadLeads, setUnreadLeads] = useState(0);
  const [unreadConsultantEnquiries, setUnreadConsultantEnquiries] = useState(0);
  const [unreadMerchantEnquiries, setUnreadMerchantEnquiries] = useState(0);


  useEffect(() => {

    const fetchUnread = async () => {
      try {
        const res = await fetch("/api/leads?limit=1000");
        if (res.ok) {
          const result = await res.json();
          const leads = result.data || [];
          const unread = leads.filter((l: any) => !l.is_read).length;
          setUnreadLeads(unread);
        }

        const resConsultant = await fetch("/api/consultant-enquiries");
        if (resConsultant.ok) {
          const enquiries = await resConsultant.json();
          const unread = enquiries.filter((e: any) => !e.is_read).length;
          setUnreadConsultantEnquiries(unread);
        }

        const resMerchant = await fetch("/api/merchant-contact-enquiries");
        if (resMerchant.ok) {
          const enquiries = await resMerchant.json();
          const unread = enquiries.filter((e: any) => !e.is_read).length;
          setUnreadMerchantEnquiries(unread);
        }
      } catch (err) { console.error(err); }
    };
    fetchUnread();


    const interval = setInterval(fetchUnread, 15000);
    return () => clearInterval(interval);
  }, []);

  if (!isAdmin) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center space-y-4">
          <h1 className="text-2xl font-bold text-foreground">Access Denied</h1>
          <p className="text-muted-foreground">You need admin privileges to access this page.</p>
          <Button className="bg-primary text-primary-foreground hover:bg-primary/90" asChild>
            <Link to="/login">Login as Admin</Link>
          </Button>
        </div>
      </div>
    );
  }

  const scrollRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const savedScrollPos = sessionStorage.getItem("adminSidebarScroll");
    if (savedScrollPos && scrollRef.current) {
      scrollRef.current.scrollTop = parseInt(savedScrollPos);
    }
  }, []);

  const handleScroll = (e: React.UIEvent<HTMLElement>) => {
    sessionStorage.setItem("adminSidebarScroll", e.currentTarget.scrollTop.toString());
  };

  return (
    <div className="min-h-screen bg-background flex">
      <aside className={`fixed inset-y-0 left-0 z-50 w-64 bg-primary transform transition-transform lg:translate-x-0 ${sidebarOpen ? "translate-x-0" : "-translate-x-full"}`}>
        <div className="flex items-center justify-between h-16 px-4 border-b border-primary-foreground/10">
          <Link to="/" className="flex items-center gap-2">
            <img src={logo} alt="IndiaIPO" className="h-8 w-auto" />
            <span className="text-xs text-primary-foreground/50">Admin</span>
          </Link>
          <button className="lg:hidden text-primary-foreground" onClick={() => setSidebarOpen(false)}>
            <X className="h-5 w-5" />
          </button>
        </div>

        <nav
          ref={scrollRef}
          onScroll={handleScroll}
          className="p-3 space-y-1 overflow-y-auto flex-1"
          style={{ maxHeight: 'calc(100vh - 64px - 160px)' }}
        >
          {sidebarLinks.map((link) => {
            const Icon = link.icon;
            const active = location.pathname === link.href;
            const badge = link.badgeKey === "leads"
              ? unreadLeads
              : link.badgeKey === "consultantEnquiries"
                ? unreadConsultantEnquiries
                : link.badgeKey === "merchantEnquiries"
                  ? unreadMerchantEnquiries
                  : 0;
            return (
              <Link
                key={link.href}
                to={link.href}
                onClick={() => setSidebarOpen(false)}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${active ? "bg-accent/20 text-accent" : "text-primary-foreground/60 hover:text-accent hover:bg-primary-foreground/5"
                  }`}
              >
                <Icon className="h-4 w-4" />
                <span className="flex-1">{link.label}</span>
                {badge > 0 && (
                  <span className="min-w-[20px] h-5 px-1.5 rounded-full bg-accent text-accent-foreground text-[10px] font-bold flex items-center justify-center">
                    {badge > 99 ? "99+" : badge}
                  </span>
                )}
              </Link>
            );
          })}
        </nav>

        <div className="absolute bottom-0 left-0 right-0 p-3 border-t border-primary-foreground/10">
          <Link to="/admin/profile" className="flex items-center gap-3 px-3 py-2 mb-2 rounded-lg hover:bg-primary-foreground/5 transition-colors group">
            <div className="w-8 h-8 rounded-full bg-accent/20 flex items-center justify-center text-accent text-xs font-bold">
              {user?.name?.[0] || "A"}
            </div>
            <div className="flex-1 min-w-0">
              <div className="text-sm font-medium text-primary-foreground truncate">{user?.name}</div>
              <div className="text-xs text-primary-foreground/40 capitalize">{user?.role?.replace("_", " ")}</div>
            </div>
            <Settings className="h-4 w-4 text-primary-foreground/40 group-hover:text-accent transition-colors" />
          </Link>
          <button
            onClick={() => { logout(); window.location.href = "/login"; }}
            className="flex items-center gap-3 px-3 py-2 w-full rounded-lg text-sm text-destructive hover:bg-destructive/10 transition-colors"
          >
            <LogOut className="h-4 w-4" />
            Logout
          </button>
        </div>
      </aside>

      <div className="flex-1 lg:ml-64">
        <header className="sticky top-0 z-40 bg-card border-b border-border h-14 flex items-center px-4 gap-4">
          <button className="lg:hidden text-foreground" onClick={() => setSidebarOpen(true)}>
            <Menu className="h-5 w-5" />
          </button>
          <h2 className="text-sm font-semibold text-foreground capitalize">
            {sidebarLinks.find((l) => l.href === location.pathname)?.label || "Admin"}
          </h2>
        </header>
        <main className="p-4 md:p-6">{children}</main>
      </div>

      {sidebarOpen && (
        <div className="fixed inset-0 z-40 bg-foreground/20 lg:hidden" onClick={() => setSidebarOpen(false)} />
      )}
    </div>
  );
};

export default AdminLayout;
